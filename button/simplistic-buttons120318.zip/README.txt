A Pen created at CodePen.io. You can find this one at https://codepen.io/ispykenny/pen/aENoQO.

 Here are 6 simple buttons that you can use for your site!