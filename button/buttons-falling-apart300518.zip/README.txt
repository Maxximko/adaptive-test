A Pen created at CodePen.io. You can find this one at https://codepen.io/ainalem/pen/wXvxgY.

 Playful way to remove buttons having them falling apart in different pieces like e.g. a jigsaw puzzle, blinds or like a zig-zag pattern